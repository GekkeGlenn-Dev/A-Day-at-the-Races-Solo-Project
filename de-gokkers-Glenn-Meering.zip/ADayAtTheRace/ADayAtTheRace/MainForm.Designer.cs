﻿namespace ADayAtTheRace
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bettorParlorGroupBox = new System.Windows.Forms.GroupBox();
            this.betsLabel = new System.Windows.Forms.Label();
            this.alBetsLabel = new System.Windows.Forms.Label();
            this.bobBetsLabel = new System.Windows.Forms.Label();
            this.joeBetsLabel = new System.Windows.Forms.Label();
            this.startRaceButton = new System.Windows.Forms.Button();
            this.dogUpDown = new System.Windows.Forms.NumericUpDown();
            this.submitBet = new System.Windows.Forms.Button();
            this.informationLabel = new System.Windows.Forms.Label();
            this.betAmmountUpAndDown = new System.Windows.Forms.NumericUpDown();
            this.selectedGuyLabel = new System.Windows.Forms.Label();
            this.alRadioButton = new System.Windows.Forms.RadioButton();
            this.bobRadioButton = new System.Windows.Forms.RadioButton();
            this.joeRadioButton = new System.Windows.Forms.RadioButton();
            this.minimumBetLabel = new System.Windows.Forms.Label();
            this.grayHound4ImageBox = new System.Windows.Forms.PictureBox();
            this.grayHound3ImageBox = new System.Windows.Forms.PictureBox();
            this.grayHound2ImageBox = new System.Windows.Forms.PictureBox();
            this.grayHound1ImageBox = new System.Windows.Forms.PictureBox();
            this.raceTrackImageBox = new System.Windows.Forms.PictureBox();
            this.bettorParlorGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dogUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.betAmmountUpAndDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayHound4ImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayHound3ImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayHound2ImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayHound1ImageBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.raceTrackImageBox)).BeginInit();
            this.SuspendLayout();
            // 
            // bettorParlorGroupBox
            // 
            this.bettorParlorGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bettorParlorGroupBox.Controls.Add(this.betsLabel);
            this.bettorParlorGroupBox.Controls.Add(this.alBetsLabel);
            this.bettorParlorGroupBox.Controls.Add(this.bobBetsLabel);
            this.bettorParlorGroupBox.Controls.Add(this.joeBetsLabel);
            this.bettorParlorGroupBox.Controls.Add(this.startRaceButton);
            this.bettorParlorGroupBox.Controls.Add(this.dogUpDown);
            this.bettorParlorGroupBox.Controls.Add(this.submitBet);
            this.bettorParlorGroupBox.Controls.Add(this.informationLabel);
            this.bettorParlorGroupBox.Controls.Add(this.betAmmountUpAndDown);
            this.bettorParlorGroupBox.Controls.Add(this.selectedGuyLabel);
            this.bettorParlorGroupBox.Controls.Add(this.alRadioButton);
            this.bettorParlorGroupBox.Controls.Add(this.bobRadioButton);
            this.bettorParlorGroupBox.Controls.Add(this.joeRadioButton);
            this.bettorParlorGroupBox.Controls.Add(this.minimumBetLabel);
            this.bettorParlorGroupBox.Location = new System.Drawing.Point(12, 230);
            this.bettorParlorGroupBox.Name = "bettorParlorGroupBox";
            this.bettorParlorGroupBox.Size = new System.Drawing.Size(722, 185);
            this.bettorParlorGroupBox.TabIndex = 0;
            this.bettorParlorGroupBox.TabStop = false;
            this.bettorParlorGroupBox.Text = "Gokkers";
            this.bettorParlorGroupBox.Enter += new System.EventHandler(this.bettorParlorGroupBox_Enter);
            // 
            // betsLabel
            // 
            this.betsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.betsLabel.AutoSize = true;
            this.betsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.betsLabel.Location = new System.Drawing.Point(314, 28);
            this.betsLabel.Name = "betsLabel";
            this.betsLabel.Size = new System.Drawing.Size(78, 24);
            this.betsLabel.TabIndex = 13;
            this.betsLabel.Text = "ingezet";
            // 
            // alBetsLabel
            // 
            this.alBetsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.alBetsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.alBetsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alBetsLabel.Location = new System.Drawing.Point(318, 108);
            this.alBetsLabel.Name = "alBetsLabel";
            this.alBetsLabel.Size = new System.Drawing.Size(396, 22);
            this.alBetsLabel.TabIndex = 12;
            // 
            // bobBetsLabel
            // 
            this.bobBetsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bobBetsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bobBetsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bobBetsLabel.Location = new System.Drawing.Point(318, 81);
            this.bobBetsLabel.Name = "bobBetsLabel";
            this.bobBetsLabel.Size = new System.Drawing.Size(396, 22);
            this.bobBetsLabel.TabIndex = 11;
            // 
            // joeBetsLabel
            // 
            this.joeBetsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.joeBetsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.joeBetsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.joeBetsLabel.Location = new System.Drawing.Point(318, 54);
            this.joeBetsLabel.Name = "joeBetsLabel";
            this.joeBetsLabel.Size = new System.Drawing.Size(396, 22);
            this.joeBetsLabel.TabIndex = 10;
            // 
            // startRaceButton
            // 
            this.startRaceButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.startRaceButton.AutoSize = true;
            this.startRaceButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startRaceButton.Location = new System.Drawing.Point(601, 151);
            this.startRaceButton.Name = "startRaceButton";
            this.startRaceButton.Size = new System.Drawing.Size(121, 34);
            this.startRaceButton.TabIndex = 9;
            this.startRaceButton.Text = "Start Race!";
            this.startRaceButton.UseVisualStyleBackColor = true;
            this.startRaceButton.Click += new System.EventHandler(this.startRaceButton_Click);
            // 
            // dogUpDown
            // 
            this.dogUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dogUpDown.Location = new System.Drawing.Point(385, 155);
            this.dogUpDown.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.dogUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.dogUpDown.Name = "dogUpDown";
            this.dogUpDown.Size = new System.Drawing.Size(55, 23);
            this.dogUpDown.TabIndex = 8;
            this.dogUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // submitBet
            // 
            this.submitBet.Location = new System.Drawing.Point(88, 154);
            this.submitBet.Name = "submitBet";
            this.submitBet.Size = new System.Drawing.Size(75, 23);
            this.submitBet.TabIndex = 7;
            this.submitBet.Text = "inzetten";
            this.submitBet.UseVisualStyleBackColor = true;
            this.submitBet.Click += new System.EventHandler(this.submitBet_Click);
            // 
            // informationLabel
            // 
            this.informationLabel.AutoSize = true;
            this.informationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.informationLabel.Location = new System.Drawing.Point(230, 157);
            this.informationLabel.Name = "informationLabel";
            this.informationLabel.Size = new System.Drawing.Size(149, 17);
            this.informationLabel.TabIndex = 6;
            this.informationLabel.Text = "Euro op hond nummer";
            this.informationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // betAmmountUpAndDown
            // 
            this.betAmmountUpAndDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.betAmmountUpAndDown.Location = new System.Drawing.Point(169, 155);
            this.betAmmountUpAndDown.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.betAmmountUpAndDown.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.betAmmountUpAndDown.Name = "betAmmountUpAndDown";
            this.betAmmountUpAndDown.Size = new System.Drawing.Size(55, 23);
            this.betAmmountUpAndDown.TabIndex = 5;
            this.betAmmountUpAndDown.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // selectedGuyLabel
            // 
            this.selectedGuyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedGuyLabel.Location = new System.Drawing.Point(6, 154);
            this.selectedGuyLabel.Name = "selectedGuyLabel";
            this.selectedGuyLabel.Size = new System.Drawing.Size(76, 23);
            this.selectedGuyLabel.TabIndex = 4;
            this.selectedGuyLabel.Text = "...";
            this.selectedGuyLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // alRadioButton
            // 
            this.alRadioButton.AutoSize = true;
            this.alRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alRadioButton.Location = new System.Drawing.Point(10, 109);
            this.alRadioButton.Name = "alRadioButton";
            this.alRadioButton.Size = new System.Drawing.Size(124, 21);
            this.alRadioButton.TabIndex = 3;
            this.alRadioButton.TabStop = true;
            this.alRadioButton.Text = "Al, Geld: € 0,00";
            this.alRadioButton.UseVisualStyleBackColor = true;
            this.alRadioButton.CheckedChanged += new System.EventHandler(this.alRadioButton_CheckedChanged);
            // 
            // bobRadioButton
            // 
            this.bobRadioButton.AutoSize = true;
            this.bobRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bobRadioButton.Location = new System.Drawing.Point(10, 82);
            this.bobRadioButton.Name = "bobRadioButton";
            this.bobRadioButton.Size = new System.Drawing.Size(137, 21);
            this.bobRadioButton.TabIndex = 2;
            this.bobRadioButton.TabStop = true;
            this.bobRadioButton.Text = "Bob, Geld: € 0,00";
            this.bobRadioButton.UseVisualStyleBackColor = true;
            this.bobRadioButton.CheckedChanged += new System.EventHandler(this.bobRadioButton_CheckedChanged);
            // 
            // joeRadioButton
            // 
            this.joeRadioButton.AutoSize = true;
            this.joeRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.joeRadioButton.Location = new System.Drawing.Point(10, 55);
            this.joeRadioButton.Name = "joeRadioButton";
            this.joeRadioButton.Size = new System.Drawing.Size(135, 21);
            this.joeRadioButton.TabIndex = 1;
            this.joeRadioButton.TabStop = true;
            this.joeRadioButton.Text = "Joe, Geld: € 0,00";
            this.joeRadioButton.UseVisualStyleBackColor = true;
            this.joeRadioButton.CheckedChanged += new System.EventHandler(this.joeRadioButton_CheckedChanged);
            // 
            // minimumBetLabel
            // 
            this.minimumBetLabel.AutoSize = true;
            this.minimumBetLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minimumBetLabel.Location = new System.Drawing.Point(6, 28);
            this.minimumBetLabel.Name = "minimumBetLabel";
            this.minimumBetLabel.Size = new System.Drawing.Size(131, 24);
            this.minimumBetLabel.TabIndex = 0;
            this.minimumBetLabel.Text = "Minimum Bet";
            // 
            // grayHound4ImageBox
            // 
            this.grayHound4ImageBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.grayHound4ImageBox.Image = global::ADayAtTheRace.Properties.Resources.afbeelding_hond;
            this.grayHound4ImageBox.Location = new System.Drawing.Point(12, 188);
            this.grayHound4ImageBox.Name = "grayHound4ImageBox";
            this.grayHound4ImageBox.Size = new System.Drawing.Size(75, 20);
            this.grayHound4ImageBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.grayHound4ImageBox.TabIndex = 5;
            this.grayHound4ImageBox.TabStop = false;
            // 
            // grayHound3ImageBox
            // 
            this.grayHound3ImageBox.Image = global::ADayAtTheRace.Properties.Resources.afbeelding_hond;
            this.grayHound3ImageBox.Location = new System.Drawing.Point(12, 132);
            this.grayHound3ImageBox.Name = "grayHound3ImageBox";
            this.grayHound3ImageBox.Size = new System.Drawing.Size(75, 20);
            this.grayHound3ImageBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.grayHound3ImageBox.TabIndex = 4;
            this.grayHound3ImageBox.TabStop = false;
            // 
            // grayHound2ImageBox
            // 
            this.grayHound2ImageBox.Image = global::ADayAtTheRace.Properties.Resources.afbeelding_hond;
            this.grayHound2ImageBox.Location = new System.Drawing.Point(12, 72);
            this.grayHound2ImageBox.Name = "grayHound2ImageBox";
            this.grayHound2ImageBox.Size = new System.Drawing.Size(75, 20);
            this.grayHound2ImageBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.grayHound2ImageBox.TabIndex = 3;
            this.grayHound2ImageBox.TabStop = false;
            // 
            // grayHound1ImageBox
            // 
            this.grayHound1ImageBox.Image = global::ADayAtTheRace.Properties.Resources.afbeelding_hond;
            this.grayHound1ImageBox.Location = new System.Drawing.Point(12, 21);
            this.grayHound1ImageBox.Name = "grayHound1ImageBox";
            this.grayHound1ImageBox.Size = new System.Drawing.Size(75, 20);
            this.grayHound1ImageBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.grayHound1ImageBox.TabIndex = 2;
            this.grayHound1ImageBox.TabStop = false;
            // 
            // raceTrackImageBox
            // 
            this.raceTrackImageBox.BackgroundImage = global::ADayAtTheRace.Properties.Resources.afbeelding_racebaan;
            this.raceTrackImageBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.raceTrackImageBox.Location = new System.Drawing.Point(12, 12);
            this.raceTrackImageBox.Name = "raceTrackImageBox";
            this.raceTrackImageBox.Size = new System.Drawing.Size(722, 212);
            this.raceTrackImageBox.TabIndex = 1;
            this.raceTrackImageBox.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 423);
            this.Controls.Add(this.grayHound4ImageBox);
            this.Controls.Add(this.grayHound3ImageBox);
            this.Controls.Add(this.grayHound2ImageBox);
            this.Controls.Add(this.grayHound1ImageBox);
            this.Controls.Add(this.raceTrackImageBox);
            this.Controls.Add(this.bettorParlorGroupBox);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.bettorParlorGroupBox.ResumeLayout(false);
            this.bettorParlorGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dogUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.betAmmountUpAndDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayHound4ImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayHound3ImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayHound2ImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grayHound1ImageBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.raceTrackImageBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox bettorParlorGroupBox;
        private System.Windows.Forms.Label minimumBetLabel;
        private System.Windows.Forms.RadioButton alRadioButton;
        private System.Windows.Forms.RadioButton bobRadioButton;
        private System.Windows.Forms.RadioButton joeRadioButton;
        private System.Windows.Forms.Label informationLabel;
        private System.Windows.Forms.NumericUpDown betAmmountUpAndDown;
        private System.Windows.Forms.Label selectedGuyLabel;
        private System.Windows.Forms.NumericUpDown dogUpDown;
        private System.Windows.Forms.Button submitBet;
        private System.Windows.Forms.Label alBetsLabel;
        private System.Windows.Forms.Label bobBetsLabel;
        private System.Windows.Forms.Label joeBetsLabel;
        private System.Windows.Forms.Button startRaceButton;
        private System.Windows.Forms.Label betsLabel;
        private System.Windows.Forms.PictureBox raceTrackImageBox;
        private System.Windows.Forms.PictureBox grayHound1ImageBox;
        private System.Windows.Forms.PictureBox grayHound2ImageBox;
        private System.Windows.Forms.PictureBox grayHound3ImageBox;
        private System.Windows.Forms.PictureBox grayHound4ImageBox;
    }
}

